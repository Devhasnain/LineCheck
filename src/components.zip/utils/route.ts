export const baseRoute = 'https://majesticowls.com/linecheck/api/'
// export const baseRoute = 'http://127.0.0.1:8000/api/'