import HomeComponent from '../../components/HomeComponent'

const page = () => {
  
  return (
   <div className="">
    <HomeComponent/>
   </div>
  )
}

export default page