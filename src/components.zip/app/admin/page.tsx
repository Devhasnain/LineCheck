import AdminCom from '@/components/AdminCom';

const page = () => {
    
    return (
        <div className='flex w-full  bg-black'>
          <AdminCom/>
        </div>
    )
}

export default page