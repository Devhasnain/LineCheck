import React from 'react'
import Signup from '@/components/Signup'
import Header1 from '@/components/Header1'


const page = () => {
  return (
    <div className='bg-black'>
       <Header1/>
        <Signup/>
    </div>
  )
}

export default page