
import SubACom from '@/components/SubACom';
// import SubComponent from '@/components/SubComponent';

const page = () => {
    
    return (
        <SubACom />
    )
}

export default page